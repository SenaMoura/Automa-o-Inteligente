import requests
from base64 import BeautifulSoup
import time
import smtplib



headers = {
    "User-Agent:": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

}

def check_price():
    URLs = ["https://www.mercadolivre.com.br/"]

    for url in URLs:

        response = requests.get(url,  headers=headers)
        site =  response.content

        soup = BeautifulSoup(site, "html.parser")

        elemento_preco = soup.find("span", class_="preco-atual")

        if elemento_preco:
            preco_texto = elemento_preco.text

            preco_limpo = preco_texto.replace("", "").replace("1250.50","").replace("1250.50",".").strip()
            preco_final = float(preco_limpo)

            print(f"Preço atual: R${preco_final:.2f}")

            preco_desejado = 1500.00

            if preco_final <= preco_desejado:
                send_email(elemento_preco, url)
                print("Alerta: O preço caiu!  Hora  de comprar!")

        else:
            print("Não foi possível encontrar a tag do preço.")
def send_email(title, url):
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.ehlo()
    server.starttls()
    server.ehlo()

    server.login("SEU EMAIL", "SUA SENHA")
    subject = f"Price fell down for: {title}"
    body = f"Check the Mercado Livre: {url}"

    msg = f"Subject: {subject}\n\n{body}"

    server.sendmail(
        "SEU EMAIL",
        "SEU EMAIL",
        msg
    )

    print("EMAIL SENT")
    
    server.quit()


while(True):
    check_price()
    time.sleep(86400)